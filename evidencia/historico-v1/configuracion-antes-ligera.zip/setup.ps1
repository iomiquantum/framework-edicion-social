param(
  [ValidateSet('pc-a-gtx1660ti','pc-b-uhd620')][string]$Perfil = 'pc-a-gtx1660ti',
  [ValidateRange(1,30)][int]$Video = 30
)
$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { throw 'Este instalador es exclusivo de Windows.' }
$KitRoot = $PSScriptRoot
$env:PYTHONUTF8 = '1'
$PythonLauncher = Get-Command py -ErrorAction Stop
$PythonPath = (& $PythonLauncher.Source -3 -c 'import sys; print(sys.executable)').Trim()
if ($LASTEXITCODE -ne 0) { throw 'Instala Python 3.11 o superior con Python Launcher.' }
$NodePath = (Get-Command node -ErrorAction Stop).Source
$FfmpegPath = (Get-Command ffmpeg -ErrorAction Stop).Source
$FfprobePath = (Get-Command ffprobe -ErrorAction Stop).Source
$NpmPath = (Get-Command npm.cmd -ErrorAction Stop).Source
$Config = @{ python=$PythonPath; node=$NodePath; ffmpeg=$FfmpegPath; ffprobe=$FfprobePath; profile=$Perfil }
$Config | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $KitRoot 'runtime.local.json') -Encoding UTF8
& $PythonPath (Join-Path $KitRoot 'tools/windows.py') doctor --profile $Perfil --video $Video
if ($LASTEXITCODE -ne 0) { throw 'Dependencias incompletas: revisa el diagnostico.' }
$Projects = Get-Content -Raw -LiteralPath (Join-Path $KitRoot 'proyectos.json') | ConvertFrom-Json
$Project = $Projects | Where-Object { $_.video -eq $Video }
if (-not $Project) { throw 'Video no incluido.' }
$VersionDir = Join-Path $KitRoot ('runtime/hyperframes/' + $Project.hyperframes)
New-Item -ItemType Directory -Path $VersionDir -Force | Out-Null
$LockPath = Join-Path $VersionDir 'package-lock.json'
if (Test-Path $LockPath) {
  & $NpmPath ci --prefix $VersionDir --no-audit --no-fund
} else {
  @{name='edicion-windows-runtime'; version='1.0.0'; private=$true; dependencies=@{hyperframes=$Project.hyperframes}} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $VersionDir 'package.json') -Encoding UTF8
  & $NpmPath install --prefix $VersionDir --no-audit --no-fund
}
if ($LASTEXITCODE -ne 0) { throw 'Fallo la instalacion local de HyperFrames.' }
$PackageDir=Join-Path $VersionDir 'node_modules/hyperframes'
$Package=Get-Content -Raw -LiteralPath (Join-Path $PackageDir 'package.json') | ConvertFrom-Json
$CliPath=Join-Path $PackageDir $Package.bin.hyperframes
& $NodePath $CliPath browser ensure
if ($LASTEXITCODE -ne 0) { throw 'Fallo la preparacion de Chrome. Revisa conexion y permisos del runtime.' }
Write-Host 'Runtime instalado. Conserva package-lock.json y usa el mismo lockfile en la otra PC antes de instalar. Ejecuta verificar-transferencia y check; instalar no aprueba el video.'
