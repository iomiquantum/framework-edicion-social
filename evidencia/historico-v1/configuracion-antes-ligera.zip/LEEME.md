# Entrega independiente para las dos PC Windows

2026-10-06 · versión 1 · **candidata a validación en Windows**.

Esta carpeta es una copia de trabajo aislada. **No cambia el framework, los comandos, los editables ni el flujo de esta Mac o de otras Mac.** Las adaptaciones viven únicamente dentro de esta entrega. No se debe reemplazar la carpeta original con esta copia.

## Qué copiar a cada computadora

Copia **toda `Entrega-Windows-v1`** a una carpeta corta local, por ejemplo `C:\ES`. Usa el mismo paquete en ambas. Su tamaño exacto y número de archivos están en `evidencia/resumen-entrega.json`. Incluye:

- Framework y sus reglas/documentación, con seis adaptaciones de compatibilidad limitadas a la copia: locks y resolución de `ffprobe.exe`.
- 30 editables principales, sus medios y evidencia incluida; VIDEO-16 usa `editable-facil-v6`.
- Los seis lotes originales, transcripciones y metadatos de ingesta existentes. No se vuelve a transcribir por cambiar de PC.
- Los dos proyectos de referencia que necesitan los catálogos de estilos, detectados por las pruebas de la copia.
- 30 MP4 seleccionados del inventario de revisión, conservando sus estados previos; inclusión no significa nueva aprobación.
- Instalación local, diagnóstico, preview, check, preflight y render candidato; dos perfiles de equipo y recibos con hashes.

No es una copia de los aproximadamente 78 GB de archivo histórico. Se excluyen entornos/binarios de Mac, cachés y temporales de render conocidos, otras versiones históricas, laboratorios adicionales, control de publicaciones y credenciales. Las exclusiones y el alcance están registrados; todo sigue disponible en el proyecto original.

## Diferencia entre los dos perfiles

| | PC A — GTX 1660 Ti | PC B — UHD 620 |
|---|---|---|
| Equipo indicado | i7 9.ª, 8 GB RAM, GTX 1660 Ti 6 GB, Windows 11 Home | i7-8550U, 16 GB RAM, UHD 620, Windows 11 Pro |
| Uso inicial | Montaje y render principal | Preparación, recursos, revisión y otro video independiente |
| Archivo | `perfiles/pc-a-gtx1660ti.json` | `perfiles/pc-b-uhd620.json` |
| Trabajos pesados | Uno a la vez | Uno a la vez inicialmente |
| Workers de render | 1 | 1 como base de comparación; ampliar solo después de medir |
| Memoria baja | Forzada si el pin de HyperFrames la admite | No forzada; queda la detección del motor |
| GPU de navegador | Detección automática | Detección automática |
| Codificación por GPU | No se fuerza inicialmente; NVENC candidato a prueba posterior | No se presupone compatibilidad del codificador |
| Calidad y resolución | Las del video, con los mismos controles | Las del video, con los mismos controles |

La GTX puede aportar a gráficos y codificación que la utilicen. Los 8 GB limitan la concurrencia; ampliar a 16 GB es la primera mejora que evaluaría si el modelo lo admite. La segunda PC tiene más margen de RAM, pero su gráfica integrada y CPU móvil tienen otro perfil. No se han medido tiempos ni fluidez en ninguno de los dos equipos. Windows Pro no se usa como indicador de velocidad. Fuentes y comparación detallada: informe `PORTABILIDAD_WINDOWS.md` de la auditoría.

## Instalación en cada PC

1. Copiar a `C:\ES`; mantener originales y caché de trabajo en disco local, preferiblemente SSD. Dejar espacio adicional para Node/Chrome, cachés y renders; el paquete no mide esos picos por adelantado.
2. Instalar **Node.js 22 o posterior** y **Python 3.11 o posterior** con Python Launcher (`py`). El entorno actual de Mac comprobó Node 24.14.1/Python 3.14.0 para el núcleo; no equivale a certificación de cualquier combinación Windows. Descargas: [Node](https://nodejs.org/en/download), [Python Windows](https://www.python.org/downloads/windows/).
3. Instalar una distribución Windows de **FFmpeg completa** desde los enlaces de [FFmpeg](https://ffmpeg.org/download.html), con `ffmpeg.exe` y `ffprobe.exe` juntos en PATH. El doctor exige `zscale`, `tonemap` y `loudnorm`. No copiar FFmpeg ni el venv de Mac.
4. Abrir una nueva terminal PowerShell. Ejecutar el instalador del perfil correspondiente:

```powershell
cd C:\ES
# PC A
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1 -Perfil pc-a-gtx1660ti -Video 30
# En la otra computadora, PC B
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1 -Perfil pc-b-uhd620 -Video 30
```

`Bypass` se limita al proceso de esa orden; no cambia la política permanente del equipo. También están los accesos `CONFIGURAR-PC-A.cmd` y `CONFIGURAR-PC-B.cmd`. La primera instalación necesita internet. Instala la versión de HyperFrames del video seleccionado dentro de esta carpeta y prepara Chrome; no actualiza pins de los editables. Para otro pin, repite setup con su número de video.

Para la segunda PC, reutiliza el `package.json` y `package-lock.json` generados en `runtime/hyperframes/<versión>/` de la primera y deja fuera `node_modules`; setup usará `npm ci`. Las dependencias transitivas quedan fijadas tras esa primera instalación, no antes. Cada PC genera su propio `runtime.local.json`: no copiar encima el de la otra, porque contiene rutas de instalación locales.

## Uso

```powershell
# Comprobar herramientas y verificar la copia antes de editar
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\editar.ps1 -Accion doctor
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\editar.ps1 -Accion verify
# Ver configuración y abrir VIDEO-30 sin producir otro MP4
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\editar.ps1 -Accion plan -Video 30
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\editar.ps1 -Accion preview -Video 30
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\editar.ps1 -Accion check -Video 30
# Solo tras revisar y aprobar el candidato para render:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\editar.ps1 -Accion render -Video 30 -AprobarRender
```

Usar estos lanzadores en Windows. Los `npm run ...`, `.command` y wrappers originales conservados en los editables documentan el funcionamiento histórico de Mac; no constituyen los lanzadores Windows.

Los resultados van a `resultados/<perfil>/VIDEO-NN/<fechaUTC>/`, con tiempo, versión, estado y un nombre nuevo `CANDIDATO.mp4`. El render ejecuta texto visible, hook/SFX y check integral antes de generar el candidato. La aprobación de render no sustituye las tres pasadas, fidelidad de plantilla, mezcla, revisión humana ni QA del MP4 exacto. Un proceso exitoso tampoco lo publica ni lo aprueba.

Se conserva la intención de entrega HLG/SDR según el MP4 seleccionado. La paridad de color, audio y composición en Windows sigue pendiente; no se promete identidad de bytes entre sistemas. El lanzador no cambia la resolución según el equipo ni fuerza NVENC.

## Qué está listo y qué falta verificar

**Preparado:** copia con hashes, perfiles, entradas PowerShell/Python, instalación local por pin, exclusión de trabajos pesados en disco local y guards de render. Los tests de la copia y pruebas del adaptador se ejecutan en Mac; las pruebas simuladas de la rama Windows no sustituyen una ejecución Windows. No se ejecutó PowerShell aquí.

**Editables con plan SFX y hook explícito encontrados:** 18, 19, 20 y 23–30. Se propone VIDEO-30 como primer caso de instalación/prueba, sin reabrir su aprobación ni sustituir su exportación anterior. El check y los guards todavía pueden descubrir problemas en destino.

**Editables heredados 01–17 y 21–22:** incluidos para consulta/edición; su render por esta entrada se detiene si no existe el plan SFX o límite contextual de hook requerido. Adaptar ese control exige una versión nueva y documentada. No se elimina el guard para presentar artificialmente los treinta como certificados.

**Audio avanzado:** están el código y los antecedentes, pero el entorno de modelos/evaluación perceptual no está instalado ni recalibrado para Windows. Las voces/SFX ya presentes se conservan y el guard habitual usa FFmpeg. Una nueva musicalización con evaluación asistida completa requiere portar ese entorno y sus controles; esta entrega no habilita limpieza especializada ni reemplaza la evaluación por una suposición.

**Recorte desde fuente y automatizaciones antiguas:** varios manifiestos históricos conservan rutas de Mac, registradas en `rutas-origen.json`. Los originales incluidos se encuentran bajo `proyecto/Serie-IA-Negocios-10-Videos/00-INGESTA`. Crear planes activos con rutas nuevas; no reescribir masivamente recibos históricos. No se declara migrado todo script de investigación, publicación o skill externa.

**Recursos web:** 25 editables usan GSAP desde CDN; esa dependencia se conserva para no editar composiciones silenciosamente. La copia no se declara autosuficiente sin internet. Congelar esos recursos requiere una nueva versión con validación.

## Cómo aprovechar ambas al mismo tiempo

1. Cada PC mantiene su copia local. Asignar **un responsable por video y versión** en una lista de trabajo: equipo, VIDEO-NN, versión de entrada y tarea.
2. Ejemplo: PC B prepara guion, recursos y geometría de VIDEO-31 mientras PC A revisa/renderiza VIDEO-30. También pueden procesar dos videos independientes cuando ambos flujos estén validados.
3. Al entregar a la otra PC, cerrar el trabajo y transferir una carpeta de versión con editable, medios nuevos, planes, QA, pin de HyperFrames y manifiesto de hashes. Copiar la carpeta completa inicialmente es más simple que adivinar dependencias.
4. Recibir en carpeta nueva, comprobar hashes y revisar. No fusionar dos cambios concurrentes sobre el mismo HTML ni sobrescribir versiones aprobadas.
5. No compartir `runtime.local.json`, venv, `node_modules`, cachés activas o carpetas de render en curso. Un lock local no coordina dos PC. Sincronización/USB son transporte de versiones cerradas, no una granja de render.

No se suman las dos GPU ni la RAM para un solo video. Esta entrega **no implementa render distribuido ni sincronización automática**. El beneficio esperado es solapar preparación, revisión y render; la ganancia depende de cuánto trabajo independiente exista y del tiempo de transferencia.

## Volver atrás

Dejar de usar esta carpeta. El proyecto original Mac no depende de ella. Las correcciones futuras de Mac se trasladan mediante otra entrega y un manifiesto de diferencias; no sincronizar de vuelta la copia adaptada sobre el original. El registro maestro solo añade lo realizado y sus límites.
