param(
  [ValidateSet('doctor','verify','list','plan','preview','check','preflight','render')][string]$Accion='plan',
  [ValidateRange(1,30)][int]$Video=30,
  [ValidateSet('pc-a-gtx1660ti','pc-b-uhd620')][string]$Perfil,
  [switch]$AprobarRender
)
$ErrorActionPreference='Stop'
if ($env:OS -ne 'Windows_NT') { throw 'Entrada exclusiva de Windows. Usa los comandos originales en Mac.' }
$ConfigFile=Join-Path $PSScriptRoot 'runtime.local.json'
if (-not (Test-Path $ConfigFile)) { throw 'Ejecuta setup.ps1 primero.' }
$Config=Get-Content -Raw -LiteralPath $ConfigFile | ConvertFrom-Json
if (-not $Perfil) { $Perfil=$Config.profile }
$Arguments=@((Join-Path $PSScriptRoot 'tools/windows.py'),$Accion,'--video',"$Video",'--profile',$Perfil)
if ($AprobarRender) { $Arguments += '--approve-render' }
$env:PYTHONUTF8='1'
& $Config.python @Arguments
exit $LASTEXITCODE
