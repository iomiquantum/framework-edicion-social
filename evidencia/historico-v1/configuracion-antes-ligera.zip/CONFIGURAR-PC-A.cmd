@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" -Perfil pc-a-gtx1660ti -Video 30
pause
