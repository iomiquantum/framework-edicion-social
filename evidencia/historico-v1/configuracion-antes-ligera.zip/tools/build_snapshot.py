"""Build an isolated Windows working snapshot. Reads the source, writes only here."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

KIT = Path(__file__).resolve().parents[1]
SERIES = 'Serie-IA-Negocios-10-Videos'
EXCLUDE = {'node_modules', '__pycache__', '.git', '.venv', 'venv', '.hyperframes',
           '.thumbnails', '.waveform-cache', '.DS_Store'}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source', type=Path, required=True)
    ap.add_argument('--apply', action='store_true')
    args = ap.parse_args()
    source = args.source.resolve()
    destination = KIT / 'proyecto'
    if source == destination or source.is_relative_to(destination):
        raise ValueError('Source cannot be the destination')
    audit = source / 'research/auditoria-framework-2026-10-06/evidencia'
    projects = json.loads((audit / 'editables-30.json').read_text())['rows']
    selections = [source/'Framework-Edicion-Social', source/SERIES/'00-INGESTA',
                  source/'AGENTS.md', source/'BITACORA_CURSO_EDICION.md',
                  source/'Miguel-Reel-Piloto', source/'WhatsApp-Reel-Prueba-Fuego']
    for name in ('scripts', 'series-memory', 'asset-intelligence', 'PROPUESTAS-ESTRUCTURA', 'LOTE-26-30-PRODUCCION'):
        selections.append(source/SERIES/name)
    selections.extend(p for p in (source/SERIES).iterdir() if p.is_file() and p.suffix in ('.md', '.json', '.py', '.js', '.cjs', '.mjs'))
    for row in projects:
        editable = source/row['path']
        selections.extend([editable, editable.parent/'source'])
        selections.extend(p for p in editable.parent.iterdir() if p.is_file() and p.suffix in ('.md', '.json', '.srt'))
    selected_videos = json.loads((audit/'muestras-mp4.json').read_text())['videos']
    transfers = {v['id']:v['transfer'] for v in selected_videos}
    for video in selected_videos:
        selections.append(source/Path(video['mp4']).relative_to(source))
    files, exclusions = {}, []

    def scan(path):
        relative = path.relative_to(source).as_posix()
        if path.name in EXCLUDE or path.suffix in ('.pyc', '.dylib') or (path.parent.name == 'renders' and path.name.startswith('work-')) or ('00-INGESTA' in path.parts and path.name == 'runtime'):
            exclusions.append({'path': relative, 'reason': 'regenerable cache or Mac runtime'})
            return
        if path.is_symlink():
            target = path.resolve()
            if not target.is_file() or not target.is_relative_to(source):
                exclusions.append({'path': relative, 'reason': 'external, directory or broken symlink'})
                return
        if path.is_dir():
            for child in sorted(path.iterdir()):
                scan(child)
        elif path.is_file():
            if any(part != part.rstrip(' .') for part in path.relative_to(source).parts):
                raise ValueError('Unsafe Windows filename: '+relative)
            files[relative] = path

    for selection in selections:
        if selection.exists():
            scan(selection)
    size = sum(p.stat().st_size for p in files.values())
    summary = {'files': len(files), 'bytes': size, 'GB_decimal': round(size/1e9, 3), 'excluded': exclusions,
               'scope': 'Framework, 30 principal editables, six original batches, source/metadata and selected exports. Not entire historical archive.'}
    (KIT/'evidencia/plan-copia.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k != 'excluded'}), flush=True)
    if not args.apply:
        return
    if destination.exists():
        raise FileExistsError('Destination exists; preserve it and create a new kit version')
    if shutil.disk_usage(KIT).free < size + 2*1024**3:
        raise RuntimeError('Insufficient space for snapshot plus 2 GiB margin')
    destination.mkdir()
    manifest = []
    for index, (relative, origin) in enumerate(sorted(files.items())):
        target = destination/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        if sys.platform == 'darwin' and origin.stat().st_size > 1024*1024:
            # APFS copy-on-write creates an independent file, never a hard link.
            cloned = subprocess.run(['/bin/cp', '-c', str(origin), str(target)], capture_output=True)
            if cloned.returncode:
                shutil.copy2(origin, target)
        else:
            shutil.copy2(origin, target)
        digest = sha(origin)
        if sha(target) != digest:
            raise RuntimeError('Copy verification failed: '+relative)
        manifest.append({'path': relative, 'source_sha256': digest, 'bytes': target.stat().st_size})
        if index % 500 == 0:
            print(f'Copied and hashed {index}/{len(files)}', flush=True)
    patches = []
    for path in (destination/'Framework-Edicion-Social/scripts').glob('*.py'):
        old = path.read_text()
        new = old.replace('import fcntl\n', 'import portable_fcntl as fcntl\n')
        new = new.replace("with_name('ffprobe')", "with_name('ffprobe.exe' if __import__('os').name == 'nt' else 'ffprobe')")
        if old != new:
            path.write_text(new)
            patches.append({'path': path.relative_to(destination).as_posix(), 'purpose': 'Windows local locks / executable suffix'})
    shutil.copy2(KIT/'tools/portable_fcntl.py', destination/'Framework-Edicion-Social/scripts/portable_fcntl.py')
    inventory = []
    for row in projects:
        editable = destination/row['path']
        wrapper = editable/'media-runtime.mjs'
        wrapper_text = wrapper.read_text() if wrapper.exists() else ''
        hooks = re.findall(r"'--hook-end','([^']+)'", wrapper_text)
        inventory.append({'video': row['id'], 'path': row['path'], 'hyperframes': row['hyperframes_versions'][0],
                          'hook_end': float(hooks[0]) if hooks else None,
                          'delivery_transfer': transfers[row['id']],
                          'sfx_plan_present': (editable/'qa/sfx-calibration.json').exists(),
                          'windows_runtime_verified': False})
    (KIT/'proyectos.json').write_text(json.dumps(inventory, ensure_ascii=False, indent=2)+'\n')
    # Historical files retain old paths and bytes; relocation is explicit, never a bulk rewrite.
    (KIT/'rutas-origen.json').write_text(json.dumps({'source_root':str(source), 'snapshot_root':'proyecto',
        'policy':'Historical absolute paths are evidence, not active Windows paths. Resolve or clone active plans before recutting.'},indent=2)+'\n')
    for record in manifest:
        record['snapshot_sha256'] = sha(destination/record['path'])
    (KIT/'evidencia/manifiesto-copia.json').write_text(json.dumps({'files':manifest,'adaptations':patches,
        'mac_modified':False,'windows_executed':False},ensure_ascii=False,indent=2)+'\n')
    print('Snapshot created; Windows runtime validation still pending.', flush=True)


if __name__ == '__main__':
    main()
