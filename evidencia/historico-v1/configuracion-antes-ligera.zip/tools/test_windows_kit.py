import errno
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

import portable_fcntl as locks
import windows


class PortableKitTests(unittest.TestCase):
    def test_real_process_exclusion_and_release(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'process.lock'
            child = "import portable_fcntl as f,sys; h=open(sys.argv[1],'a+b'); f.flock(h,f.LOCK_EX|f.LOCK_NB)"
            env = {**os.environ, 'PYTHONPATH':str(Path(__file__).parent)}
            with path.open('a+b') as handle:
                locks.flock(handle, locks.LOCK_EX)
                blocked = subprocess.run([sys.executable,'-c',child,str(path)],env=env,capture_output=True)
                self.assertNotEqual(blocked.returncode,0)
                locks.flock(handle, locks.LOCK_UN)
                free = subprocess.run([sys.executable,'-c',child,str(path)],env=env,capture_output=True)
                self.assertEqual(free.returncode,0,free.stderr)

    def test_windows_branch_restores_position_and_unlocks(self):
        with tempfile.TemporaryFile() as handle:
            handle.write(b'abcdef'); handle.flush(); handle.seek(3)
            calls=[]
            m=types.SimpleNamespace(LK_NBLCK=2,LK_UNLCK=0,locking=lambda fd, op, n:calls.append((op,n,os.lseek(fd,0,os.SEEK_CUR))))
            with patch.object(locks.os,'name','nt'),patch.dict(sys.modules,msvcrt=m):
                locks.flock(handle,locks.LOCK_SH)
                self.assertEqual(handle.tell(),3)
                locks.flock(handle,locks.LOCK_UN)
            self.assertEqual(calls,[(2,1,0),(0,1,0)])

    def test_windows_branch_nonblocking_conflict(self):
        def conflict(*args): raise OSError(errno.EACCES,'locked')
        m=types.SimpleNamespace(LK_NBLCK=2,LK_UNLCK=0,locking=conflict)
        with tempfile.TemporaryFile() as handle:
            with patch.object(locks.os,'name','nt'),patch.dict(sys.modules,msvcrt=m):
                with self.assertRaises(BlockingIOError):locks.flock(handle,locks.LOCK_EX|locks.LOCK_NB)

    def test_manifest_cannot_redirect_to_mac_or_parent(self):
        with patch.object(windows,'read',return_value=[{'video':30,'path':'../../source-mac'}]):
            with self.assertRaisesRegex(ValueError,'outside'):windows.project(30)

    def test_missing_sfx_plan_blocks_before_mix(self):
        with tempfile.TemporaryDirectory() as folder:
            with patch.object(windows,'execute') as run:
                with self.assertRaisesRegex(RuntimeError,'SFX plan'):
                    windows.preflight({'hook_end':None},Path(folder),{'ffmpeg':'ffmpeg','ffprobe':'ffprobe'},Path(folder)/'qa')
                self.assertEqual(run.call_count,1) # Visible-text guard runs; no guessed audio plan.

    def test_copy_receipt_keeps_distinct_source_and_adapted_hashes(self):
        m=windows.read(windows.ROOT/'evidencia/manifiesto-copia.json')
        changed={r['path'] for r in m['files'] if r['source_sha256']!=r['snapshot_sha256']}
        self.assertEqual(changed,{r['path'] for r in m['adaptations']})
        self.assertTrue(changed)


if __name__=='__main__':unittest.main()
