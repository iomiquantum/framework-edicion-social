@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" -Perfil pc-b-uhd620 -Video 30
pause
