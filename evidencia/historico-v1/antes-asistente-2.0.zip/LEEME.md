# Entrega Windows ligera — para videos nuevos

Actualizada el 2026-10-06. **Esta es la misma carpeta de entrega, ahora reducida.** Se eliminaron las copias de trabajos anteriores; los originales y el flujo Mac quedaron intactos. Windows todavía requiere instalación y validación en las PC.

## Qué copiar

Copia únicamente esta carpeta `Entrega-Windows-v1` a cada PC, por ejemplo a `C:\ES`. **Ya no necesitas trasladar los 18,1 GB del paquete anterior.** El tamaño actual y la reducción están en `evidencia/resumen-entrega.json`.

Se conserva:

- **Memoria e instrucciones:** [INICIO_PARA_CODEX.md](INICIO_PARA_CODEX.md), AGENTS, bitácora, preferencias, reglas y controles.
- **30 propuestas de plantilla:** fichas, visor, tableros y sus estados de diseño. [Abrir catálogo](proyecto/Serie-IA-Negocios-10-Videos/PROPUESTAS-ESTRUCTURA/CATALOGO-PLANTILLAS/index.html).
- **Código de referencia de las 30 plantillas**, tres estilos y 18 módulos declarativos. Es material para adaptar al nuevo video, no treinta editables terminados sin sus medios.
- **Recursos reutilizables:** fuentes/SVG deduplicados, iconos, música, SFX y registros de licencia/procedencia/feedback. Se conservan las restricciones de uso y los descartes documentados.
- **Scripts, instalador y perfiles para ambas PC**, con controles de texto y audio, hashes y salidas por versión.

Se quitaron los seis brutos antiguos, MP4/MOV exportados, voces y mezclas de prueba de esos trabajos, capturas de QA, cachés y los proyectos de edición anteriores. Los tableros conservan imágenes pequeñas de referencia visual; no son grabaciones ni proyectos completos. No hay un archivo ZIP oculto con los videos eliminados: solo se guardó historia textual/configuración para explicar la reducción.

## La memoria para continuar con lo trabajado

**[INICIO_PARA_CODEX.md](INICIO_PARA_CODEX.md)** es el punto de entrada para Codex en la PC. Explica qué leer, dónde están las plantillas/estilos y cómo aplicar lo aprendido a una grabación nueva. No sustituye las reglas completas: enlaza sus ubicaciones dentro de esta misma entrega.

Los archivos `*.referencia` de `proyecto/plantillas-codigo/` conservan composición y movimiento. No abrirlos como un video terminado: el texto, la voz, los tiempos y los recursos específicos deben adaptarse al nuevo material. Las aprobaciones de videos antiguos no se trasladan a uno nuevo.

## Perfiles de las dos PC

| Perfil | Equipo | Ajuste inicial |
|---|---|---|
| `pc-a-gtx1660ti` | i7 de 9.ª, 8 GB RAM, GTX 1660 Ti 6 GB | Un worker, un trabajo pesado y memoria baja cuando el motor la admita. Principal candidata para montaje/render. |
| `pc-b-uhd620` | i7-8550U, 16 GB RAM, UHD 620 | Un worker como base de comparación. Preparación, revisión y otro video independiente. |

Ambas conservan las mismas plantillas y controles de calidad. No se fuerza codificación GPU ni se cambia resolución para aparentar rapidez. Los tiempos reales quedan por medir. Cada PC debe tener su configuración local y trabajos asignados; no editar simultáneamente el mismo archivo compartido.

## Instalación en Windows

1. Copiar la carpeta a `C:\ES`.
2. Instalar [Node.js](https://nodejs.org/en/download) 22 o posterior y [Python](https://www.python.org/downloads/windows/) 3.11 o posterior, con Python Launcher (`py`). El núcleo se verificó en Mac con Node 24.14.1/Python 3.14.0; no se certifica cualquier combinación Windows.
3. Instalar un [FFmpeg completo para Windows](https://ffmpeg.org/download.html), con `ffmpeg.exe` y `ffprobe.exe` juntos en PATH. El diagnóstico exige `zscale`, `tonemap` y `loudnorm`.
4. Abrir `CONFIGURAR-PC-A.cmd` o `CONFIGURAR-PC-B.cmd`, según el equipo. También se puede ejecutar:

```powershell
cd C:\ES
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1 -Perfil pc-a-gtx1660ti
# En la otra PC, usar -Perfil pc-b-uhd620
```

El ajuste Bypass pertenece solamente a ese proceso. El instalador prepara HyperFrames 0.8.102 y Chrome dentro de su entorno de ejecución; requiere internet. No necesita VIDEO-30 ni ningún video anterior. Instalar no aprueba ni renderiza nada.

Tras la primera instalación, conserva el `package-lock.json` de `runtime/hyperframes/0.8.102/`. Para igualar dependencias en la segunda PC, copia allí ese lockfile y su package.json antes de instalar; no traslades `node_modules` ni `runtime.local.json`. Node/Python/FFmpeg/Chrome y cachés ocuparán espacio adicional al tamaño de esta entrega.

## Empezar un nuevo video

```powershell
# Preparar carpetas para VIDEO-31 con la plantilla T05
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\editar.ps1 -Accion nuevo -Video 31 -Plantilla T05
# Consultar la configuración preparada
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\editar.ps1 -Accion plan -Video 31
```

La acción `nuevo` crea `proyecto/Nuevos-Videos/VIDEO-31/`: fuente nueva, carpeta editable, revisión de fidelidad y selección de plantilla. El registro empieza vacío. **No genera un montaje ni inventa una aprobación**; prepara el lugar de trabajo y evita sobrescribir otro video.

Coloca el nuevo bruto o lote en `source/`. Pide a Codex que lea `INICIO_PARA_CODEX.md` y edite esa grabación aplicando la plantilla elegida. Debe consultar la voz real, preparar la maqueta y construir `editable/index.html`; el registro de inicio debe reflejar documentos realmente consultados.

Después del montaje:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\editar.ps1 -Accion preview -Video 31
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\editar.ps1 -Accion check -Video 31
# Únicamente después de revisar y aprobar el candidato para render:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\editar.ps1 -Accion render -Video 31 -AprobarRender
```

El editable necesita un plan SFX verificable y el límite contextual del hook en `windows-project.json`. Los guards bloquean el render cuando faltan. Las tres pasadas y el QA del MP4 exacto siguen vigentes. Las salidas nuevas van a `resultados/<perfil>/VIDEO-NN/<fecha>/`; nunca se escriben sobre los originales de Mac.

## Verificar la entrega

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\editar.ps1 -Accion doctor
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\editar.ps1 -Accion verify
```

`verify` comprueba los archivos distribuidos por hash antes de editar; los nuevos videos se registran aparte. Los tests locales, alcance y preservación están en `evidencia/resumen-entrega.json`. Los logs de intentos anteriores se conservan como historia, no como resultado de esta edición ligera.

**Pendiente:** ejecución real de PowerShell/Chrome/render en Windows, paridad audiovisual y medición en ambas PC. El entorno avanzado de modelos/evaluación de audio no quedó instalado ni calibrado para Windows; su estado pendiente se mantiene. Las skills del editor deben estar disponibles en la PC; no se copian ejecutables, sesiones ni venv de la Mac.
