# Changelog de la entrega Windows

## 2026-10-06 — v1.1 ligera, misma carpeta

- Eliminación autorizada de trabajos anteriores dentro de esta entrega: grabaciones, exports, voces/mezclas de prueba, capturas y cachés. Originales Mac intactos.
- Conserva 30 fichas/tableros y referencias de código, tres estilos, recetas y recursos con procedencia. Tableros deduplican cuatro imágenes, sin cambiar sus píxeles.
- Memoria operativa `INICIO_PARA_CODEX.md`; instalador independiente de un video anterior y acción `nuevo` con selección de plantilla. Proyectos iniciales vacíos.
- Catálogos Windows distinguen referencias de código de aprobaciones históricas; originales textuales en `evidencia/historico-v1`. No revoca aprobaciones del proyecto Mac.
- Validador, 329 tests del framework y nueve del adaptador PASS local; preservados intentos fallidos y corregidos fixtures ligados al archivo retirado. Windows no ejecutado.
- Tamaño y recibos vigentes en `evidencia/resumen-entrega.json`. La v1 completa descrita abajo es historia, no el contenido actual.


## 2026-10-06 — v1 independiente, candidata

- Petición: preparar archivos para las dos PC, explicar diferencias y no modificar el framework/flujo de Mac.
- Copia independiente con treinta editables principales, seis lotes, framework y referencias de estilos. Exclusiones de runtime/cachés documentadas; no archivo histórico completo.
- Dos perfiles; mismo criterio editorial, un trabajo pesado por equipo, memoria baja para PC A. Codificación GPU sin activar automáticamente.
- Lanzadores, instalador local por pin, guards, diagnóstico, hashes, bloqueos locales y salidas con fecha. Adaptaciones solo en la copia.
- Primer ensayo de 328 tests de la copia detectó referencias a dos proyectos de estilos ausentes. Se conservó el fallo y se incluyeron sus proyectos antes de repetir tests/validador; no se alteró el catálogo para esconder el problema.
- Estado final y evidencia de preservación en `evidencia/resumen-entrega.json`. Windows/PowerShell, paridad visual/audio y rendimiento en ambas PC pendientes. Audio avanzado y planes absolutos heredados requieren adaptación adicional.
- No modifica código, reglas, scripts, versiones, editables o medios originales del flujo Mac. La bitácora maestra recibe una entrada documental; no se cambia el changelog ni las reglas del framework original.
