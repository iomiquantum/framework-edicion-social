# Framework de edición · entrega portátil 2.0

**Empieza por [INICIO Y CONFIGURACION DE FRAMEWORK.md](./INICIO%20Y%20CONFIGURACION%20DE%20FRAMEWORK.md).**

Doble clic en el archivo del mismo nombre: `.cmd` para Windows o `.command` para Mac. Abre un asistente local de seis pasos: equipo → contexto → colores → plantillas → masters → empezar en Codex.

Esta misma carpeta conserva las 30 propuestas, referencias de código, reglas, recursos reutilizables, skills y memoria del trabajo. No incluye renders ni grabaciones de videos anteriores. Los masters nuevos se referencian sin duplicarlos.

Las herramientas se verifican e instalan con autorización. La configuración es propia de cada equipo. Conserva una copia local independiente en cada máquina; no trabajes simultáneamente sobre el mismo lote sincronizado.

- `INICIO_PARA_CODEX.md`: guía para continuar la edición con las reglas existentes.
- `proyecto/`: carpeta que abrir en Codex para editar.
- `entrada-masters/`: lugar opcional para los nuevos originales.
- `asistente/` y `tools/`: interfaz y automatización de esta entrega.
- `perfiles/`: diferencias entre las PC A/B y Mac.
- `evidencia/`: pruebas, hashes, historia y límites reales de validación.
- `CHANGELOG.md`: evolución de la entrega; las versiones documentales anteriores se conservan en `evidencia/historico-v1/`.

Si usas CLI avanzada: `python tools/windows.py --help`. El nombre `windows.py` se conserva por compatibilidad, pero ahora admite el runtime aislado de Mac. La aprobación requerida para render y el QA no cambian.
