#!/usr/bin/env python3
"""Loopback-only wizard; per-session capability, origin checks and explicit install plans."""
from __future__ import annotations
import argparse, sys, hashlib, http.server, json, mimetypes, os, secrets, shutil, threading, time, urllib.parse, webbrowser
from pathlib import Path
import onboarding as ob
import runtime_setup as rt
ROOT=Path(__file__).resolve().parents[1]
TOKEN=secrets.token_urlsafe(32)
STATE={'job':None,'versions':None,'plans':{},'diagnosis':None,'smoke':None}
BUSY=threading.Lock()

def smoke():
    """A tiny technical test, never a render or approval of the person's new video."""
    cmd,v=rt.hf_command();env=rt.environment();ff=rt.binary('ffmpeg');probe=rt.binary('ffprobe')
    if not ff or not probe:raise ValueError('Completa FFmpeg primero.')
    dest=ROOT/'resultados/prueba-equipo'/time.strftime('%Y%m%d-%H%M%S');dest.mkdir(parents=True)
    package=ROOT/'runtime/hyperframes'/v/'node_modules/gsap/dist/gsap.min.js'
    if not package.exists():raise ValueError('Prepara HyperFrames y GSAP primero.')
    shutil.copy2(package,dest/'gsap.min.js')
    rt.run([ff,'-v','error','-f','lavfi','-i','sine=frequency=440:duration=1','-ar','48000',dest/'tono.wav'])
    (dest/'index.html').write_text('''<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;width:100%;height:100%;overflow:hidden}#root{width:100%;height:100%;position:relative;background:#102d40}.box{position:absolute;left:30px;top:180px;width:80px;height:80px;background:#eff5f4}</style><script src="gsap.min.js"></script></head><body><div id="root" data-composition-id="setup-test" data-width="360" data-height="640" data-duration="1"><div class="box"></div><audio id="test-tone" class="clip" data-start="0" data-duration="1" data-track-index="1" src="tono.wav"></audio></div><script>window.__timelines=window.__timelines||{};window.__timelines['setup-test']=gsap.timeline({paused:true}).to('.box',{x:180,duration:1,ease:'none'});</script></body></html>''',encoding='utf-8')
    evidence={'version':v,'platform':rt.hardware(),'at':rt.now(),'scope':'Prueba técnica sintética de 1 s; no QA ni aprobación de video real.'}
    evidence['check']=rt.run(cmd+['check',str(dest)],env=env,timeout=180)[-6000:]
    evidence['render']=rt.run(cmd+['render',str(dest),'--output',str(dest/'prueba.mp4'),'--workers','1'],env=env,timeout=360)[-6000:]
    data=json.loads(rt.run([probe,'-v','error','-show_streams','-show_format','-of','json',dest/'prueba.mp4']))
    if not any(x['codec_type']=='audio' for x in data['streams']) or not any(x['codec_type']=='video' for x in data['streams']):raise RuntimeError('Prueba sin video o audio.')
    if not .8<float(data['format']['duration'])<1.5:raise RuntimeError('Duración de prueba inesperada.')
    # Decode the actual output and verify motion, not just a successful command exit.
    import subprocess
    decoded=subprocess.run([ff,'-v','error','-i',str(dest/'prueba.mp4'),'-vf','fps=4,scale=36:64','-f','rawvideo','-pix_fmt','rgb24','-'],capture_output=True,check=True).stdout
    size=36*64*3
    if len(decoded)<size*2 or decoded[:size]==decoded[-size:]:raise RuntimeError('La prueba no conserva movimiento visible.')
    import array, math
    raw_audio=subprocess.run([ff,'-v','error','-i',str(dest/'prueba.mp4'),'-vn','-ac','1','-ar','16000','-f','f32le','-'],capture_output=True,check=True).stdout
    samples=array.array('f');samples.frombytes(raw_audio)
    rms=math.sqrt(sum(x*x for x in samples)/max(1,len(samples)))
    if not math.isfinite(rms) or rms<.001:raise RuntimeError('La pista de la prueba está vacía o en silencio.')
    evidence.update(status='pass',probe=data,decoded_motion=True,audio_rms=rms,dependencies_fingerprint=fingerprint())
    rt.save(dest/'recibo.json',evidence);rt.save(ROOT/'resultados/prueba-equipo-actual.json',evidence)
    return evidence

def fingerprint():
    c=rt.config();paths={k:rt.binary(k) for k in ('node','ffmpeg','ffprobe')}
    stamps={k:[v,Path(v).stat().st_size,Path(v).stat().st_mtime_ns] if v else None for k,v in paths.items()}
    return hashlib.sha256(json.dumps({'paths':stamps,'hf':c.get('hyperframes'),'os':os.name,'machine':rt.hardware()['cpu']},sort_keys=True).encode()).hexdigest()

def job(fn):
    if not BUSY.acquire(False):raise ValueError('Hay una tarea en curso. Espera su resultado.')
    STATE['job']={'status':'running','started':rt.now()}
    def target():
        try:STATE['job']={'status':'pass','result':fn()}
        except Exception as e:STATE['job']={'status':'fail','error':str(e)}
        finally:BUSY.release()
    threading.Thread(target=target,daemon=True).start()
    return {'status':'running'}

class Handler(http.server.BaseHTTPRequestHandler):
    server_version='EdicionPortable/2'
    def log_message(self,*a):pass
    def send(self,data,kind='application/json',status=200):
        if kind=='application/json':data=json.dumps(data,ensure_ascii=False).encode()
        elif isinstance(data,str):data=data.encode()
        self.send_response(status);self.send_header('Content-Type',kind+'; charset=utf-8');self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Content-Security-Policy',"default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; frame-ancestors 'none'")
        self.end_headers();self.wfile.write(data)
    def authorized(self):
        expected=f'127.0.0.1:{self.server.server_port}'
        if self.headers.get('Host')!=expected:return False
        if self.headers.get('Origin') not in (None,'http://'+expected):return False
        return secrets.compare_digest(self.headers.get('X-Setup-Token',''),TOKEN)
    def do_GET(self):
        try:
            parsed=urllib.parse.urlparse(self.path);path=parsed.path;q=urllib.parse.parse_qs(parsed.query)
            if self.headers.get('Host')!=f'127.0.0.1:{self.server.server_port}':return self.send({'error':'Host inválido'},status=403)
            if path=='/':return self.send((ROOT/'asistente/index.html').read_bytes(),'text/html')
            if path in ('/app.js','/style.css'):
                return self.send((ROOT/'asistente'/path[1:]).read_bytes(),'text/javascript' if path.endswith('.js') else 'text/css')
            if path.startswith('/assets/'):
                name=Path(path).name;base=(ROOT/rt.read(ROOT/'kit-config.json')['templates']).parent/'assets-compartidos'
                if path!='/assets/'+name or not (base/name).is_file():raise ValueError('Recurso no encontrado')
                return self.send((base/name).read_bytes(),mimetypes.guess_type(name)[0] or 'application/octet-stream')
            if path=='/board':
                p=ob.selected_palette({'palette':q.get('palette',['bosque'])[0],'colors':json.loads(q['colors'][0]) if 'colors' in q else None}) if 'palette' in q or 'colors' in q else None
                return self.send(ob.board(q.get('template',['T01'])[0],p,embed=True),'image/svg+xml')
            if not self.authorized():return self.send({'error':'Sesión inválida. Abre el enlace de la terminal.'},status=403)
            if path=='/api/info':
                return self.send({'root':str(ROOT),'workspace':str(ROOT/'proyecto'),'hardware':rt.hardware(),'catalog':ob.catalog(),'job':STATE['job'],'runtime':rt.config(),'styles':rt.read(ROOT/'proyecto/Framework-Edicion-Social/styles/catalog.json'),'entry':str(ROOT/'entrada-masters')})
            if path=='/api/job':return self.send(STATE['job'] or {'status':'idle'})
            return self.send({'error':'No encontrado'},status=404)
        except Exception as e:self.send({'error':str(e)},status=400)
    def do_POST(self):
        if not self.authorized():return self.send({'error':'Origen o sesión no autorizados'},status=403)
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=120000:raise ValueError('Tamaño de solicitud inválido')
            data=json.loads(self.rfile.read(length));path=urllib.parse.urlparse(self.path).path
            if path=='/api/diagnose':
                def diag():
                    d=rt.diagnose();STATE['diagnosis']=d;return d
                return self.send(job(diag))
            if path=='/api/versions':
                def versions():STATE['versions']=rt.latest();return STATE['versions']
                return self.send(job(versions))
            if path=='/api/plan':
                if not STATE['versions']:raise ValueError('Consulta versiones antes de preparar una instalación.')
                p=rt.installation_plan(data['kind'],STATE['versions']);STATE['plans'][p['id']]=p;return self.send(p)
            if path=='/api/install':
                if data.get('authorize') is not True:raise ValueError('Confirma la autorización antes de descargar.')
                if BUSY.locked():raise ValueError('Espera la tarea actual.')
                p=STATE['plans'].pop(data.get('id'),None)
                if not p:raise ValueError('Plan desconocido o ya utilizado')
                STATE['diagnosis']=None;STATE['smoke']=None
                return self.send(job(lambda:rt.perform(p,authorized=True)))
            if path=='/api/smoke':
                if data.get('authorize') is not True:raise ValueError('Autoriza la prueba de 1 segundo.')
                def test():STATE['smoke']=smoke();return STATE['smoke']
                return self.send(job(test))
            if path=='/api/palettes':return self.send(ob.suggestions(str(data.get('context',''))[:20000]))
            if path=='/api/prepare':
                return self.send(job(lambda:ob.prepare(data)))
            if path=='/api/ready':
                d=STATE['diagnosis'];s=STATE['smoke']
                ok=bool(d and d['dependencies_ok'] and s and s.get('status')=='pass' and s.get('dependencies_fingerprint')==fingerprint() and data.get('codex_signed_in') is True)
                return self.send({'ready':ok,'codex_verification':'confirmado por el usuario' if data.get('codex_signed_in') else 'pendiente','message':'Ya tienes todo listo para empezar a editar. Abre Codex y continúa con el lote preparado.' if ok else 'Puedes preparar el lote. Para confirmar que todo está listo, completa diagnóstico, prueba de render e inicio de sesión en Codex.'})
            return self.send({'error':'Acción no encontrada'},status=404)
        except Exception as e:self.send({'error':str(e)},status=400)

def main():
    p=argparse.ArgumentParser();p.add_argument('--no-browser',action='store_true');p.add_argument('--codex',action='store_true');p.add_argument('--edit',nargs=argparse.REMAINDER);p.add_argument('--port',type=int,default=0);args=p.parse_args()
    if args.edit:
        sys.argv=[str(ROOT/'tools/windows.py'),*args.edit]
        rt.windows.main();return
    if args.codex:
        from abrir_codex import main as open_codex
        open_codex();return
    server=http.server.ThreadingHTTPServer(('127.0.0.1',args.port),Handler)
    url=f'http://127.0.0.1:{server.server_port}/#{TOKEN}'
    print('INICIO Y CONFIGURACION DE FRAMEWORK\n'+url+'\nDeja esta terminal abierta. Ctrl+C cierra el asistente.',flush=True)
    if not args.no_browser:webbrowser.open(url)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
if __name__=='__main__':main()
